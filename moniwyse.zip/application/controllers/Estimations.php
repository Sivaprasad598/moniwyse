<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Estimations extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		
	}



	public function addEstIncome()
	{

		parse_str($_POST['formdata'],$est_data);

        $user_id = 1;

		$data['USD'] = $est_data['est_in_amount'];
		$data['NGN'] = $est_data['est_in_amount'];
		$data['GBP'] = $est_data['est_in_amount'];
		$data['EUR'] = $est_data['est_in_amount'];
		$data['CurrencyType'] = $est_data['est_in_currency'];
		$data['Amount'] = $est_data['est_in_amount'];
		$data['Type'] = $est_data['est_in_type'];
		$data['SubCategoryId'] = $est_data['est_in_sub_category'];
        $data['CategoryId'] = $est_data['est_in_category'];
        $data['RenewDays'] = $est_data['est_in_renew_days'];

        if($est_data['est_in_renew_days'] == '30')
        {
            $renew_period = '1 month';
        }else if($est_data['est_in_renew_days'] == '90')
        {
            $renew_period = '3 months';
        }else if($est_data['est_in_renew_days'] == '180')
        {
            $renew_period = '6 months';
        }else{
            $renew_period = '1 year';
        }
        $data['RenewPeriod'] = $renew_period;

        
        $data['UserId'] = $user_id;

		if($this->db->insert('estimations',$data))
		{
			echo 1;
		}else{
			echo 0;
		}
	}
	

	public function addEstExpense()
	{
		parse_str($_POST['formdata'],$est_data);

		
        $user_id = 1;

		$data['USD'] = $est_data['est_ex_amount'];
		$data['NGN'] = $est_data['est_ex_amount'];
		$data['GBP'] = $est_data['est_ex_amount'];
		$data['EUR'] = $est_data['est_ex_amount'];
		$data['CurrencyType'] = $est_data['est_ex_currency'];
		$data['Amount'] = $est_data['est_ex_amount'];
		$data['Type'] = $est_data['est_ex_type'];
		$data['SubCategoryId'] = $est_data['est_ex_sub_category'];
        $data['CategoryId'] = $est_data['est_ex_category'];
        $data['RenewDays'] = $est_data['est_ex_renew_days'];

        if($est_data['est_ex_renew_days'] == '30')
        {
            $renew_period = '1 month';
        }else if($est_data['est_ex_renew_days'] == '90')
        {
            $renew_period = '3 months';
        }else if($est_data['est_ex_renew_days'] == '180')
        {
            $renew_period = '6 months';
        }else{
            $renew_period = '1 year';
        }
        $data['RenewPeriod'] = $renew_period;

        
        $data['UserId'] = $user_id;

		if($this->db->insert('estimations',$data))
		{
			echo 1;
		}else{
			echo 0;
		}
	}
    public function loadEstimations()
    {
        $user_id = 1;


        $this->db->select('estimations.CategoryId,categories.Name');
        $this->db->distinct('CategoryId');
        $this->db->from('estimations');
        $this->db->join('categories', 'categories.Id = estimations.CategoryId','left');
        $this->db->where('estimations.UserId',$user_id);
        $this->db->order_by('categories.SortingOrder');
        $query = $this->db->get();
        $categories = $query->result_array();

        $data['categories'] = $categories;

       
        echo $this->load->view('est_block',$data,TRUE);
    }
	
}
